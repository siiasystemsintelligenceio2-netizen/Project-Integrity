# Contributing

## Basic Workflow

1. Create a branch.
2. Make changes.
3. Run local checks:

   ```bash
   npm run validate
   npm test
   npm run build
   ```

4. Open a pull request.
5. Wait for CI to pass.
6. Merge after review.

## Commit Message Examples

```text
Add live deployment workflow
Update GitHub Pages instructions
Fix package validation
```
