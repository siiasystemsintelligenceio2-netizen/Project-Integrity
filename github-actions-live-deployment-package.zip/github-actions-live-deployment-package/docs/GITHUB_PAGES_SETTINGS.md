# GitHub Pages Settings

After you upload this package to GitHub, configure Pages one time.

## Required Setting

Go to:

```text
Repository > Settings > Pages
```

Under **Build and deployment**, set:

```text
Source: GitHub Actions
```

After this is configured, the workflow in `.github/workflows/deploy-pages.yml` can publish the site.

## Where the Live URL Appears

After deployment finishes:

1. Open the repository.
2. Go to **Actions**.
3. Open **Deploy GitHub Pages**.
4. Open the latest successful run.
5. The deployment URL appears in the job summary and environment section.

The usual GitHub Pages URL format is:

```text
https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/
```

For an organization repository:

```text
https://YOUR-ORGANIZATION.github.io/YOUR-REPOSITORY/
```

## Custom Domain Later

You can add a custom domain later from:

```text
Repository > Settings > Pages > Custom domain
```

Do not configure a custom domain until the default GitHub Pages URL works.
