# GitHub Actions Simplified

## Plain-English Model

| GitHub Actions Term | Simple Meaning | Example |
| --- | --- | --- |
| Workflow | Automation file | `.github/workflows/deploy-pages.yml` |
| Event / Trigger | What starts automation | `push`, `pull_request`, `workflow_dispatch` |
| Job | A block of work | `build`, `deploy` |
| Runner | The machine that runs the job | `ubuntu-latest` |
| Step | One action or command inside a job | `npm run build` |
| Action | Reusable automation component | `actions/deploy-pages@v4` |
| Permissions | Access granted to the workflow token | `pages: write` |
| Artifact | Files passed to deployment | `dist/` |

## Minimum Live Deployment Flow

```yaml
on:
  push:
    branches:
      - main

permissions:
  contents: read
  pages: write
  id-token: write
```

A GitHub Pages deployment normally follows this sequence:

1. Check out repository.
2. Set up Node.js.
3. Install dependencies.
4. Validate package.
5. Run tests.
6. Build static files into `dist/`.
7. Upload `dist/` as a Pages artifact.
8. Deploy the Pages artifact.

## Safe Defaults

Use restricted permissions where possible. For CI, use:

```yaml
permissions:
  contents: read
```

For GitHub Pages deployment, the deploy workflow needs:

```yaml
permissions:
  contents: read
  pages: write
  id-token: write
```

Never commit secrets into the repository.
