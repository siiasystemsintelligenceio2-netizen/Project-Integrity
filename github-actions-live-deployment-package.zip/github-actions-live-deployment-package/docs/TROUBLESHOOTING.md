# Troubleshooting

## Deployment Workflow Does Not Show

Check that this file exists:

```text
.github/workflows/deploy-pages.yml
```

The file must use `.yml` or `.yaml` and must be inside `.github/workflows/`.

## GitHub Pages Says Source Is Not Configured

Go to:

```text
Repository > Settings > Pages
```

Set:

```text
Source: GitHub Actions
```

## Deploy Job Fails With Permission Error

Confirm `.github/workflows/deploy-pages.yml` includes:

```yaml
permissions:
  contents: read
  pages: write
  id-token: write
```

Then confirm repository Actions are enabled:

```text
Repository > Settings > Actions > General
```

## Build Fails

Run locally:

```bash
npm ci --ignore-scripts
npm run validate
npm test
npm run build
```

Most build failures are caused by missing files, renamed folders, or deleted scripts.

## Site Shows Old Content

1. Confirm the latest deployment completed successfully.
2. Hard-refresh the browser.
3. Wait for GitHub Pages cache to update.
4. Confirm `public/index.html` was changed before pushing.

## Do Not Upload Secrets

Do not commit:

- `.env`
- API keys
- tokens
- passwords
- private certificates
- client secrets

Use GitHub Secrets for sensitive values.
