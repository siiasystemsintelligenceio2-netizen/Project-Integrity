# Live Deployment Steps

This package is configured for GitHub Pages live deployment.

## Step 1: Create Repository

1. Sign in to GitHub.
2. Click **+** in the top-right corner.
3. Click **New repository**.
4. Repository name example:

   ```text
   github-actions-live-deployment-package
   ```

5. Choose **Public** or **Private**.
6. Do **not** add a README, license, or `.gitignore`.
7. Click **Create repository**.

## Step 2: Upload Package

1. Extract this ZIP file.
2. Open the extracted folder.
3. In GitHub, click **Add file > Upload files**.
4. Drag all files and folders into the upload area.
5. Commit directly to `main` with this message:

   ```text
   Initial commit: add live deployment package
   ```

## Step 3: Enable GitHub Pages Source

Go to:

```text
Repository > Settings > Pages
```

Set:

```text
Build and deployment > Source > GitHub Actions
```

## Step 4: Run Deployment

The deployment starts automatically after pushing to `main`.

To run it manually:

```text
Repository > Actions > Deploy GitHub Pages > Run workflow
```

## Step 5: Confirm Live Site

1. Open **Actions**.
2. Select **Deploy GitHub Pages**.
3. Open the latest run.
4. Confirm both jobs pass:
   - `Build static site`
   - `Deploy to GitHub Pages`
5. Open the published URL.

## Step 6: Local Validation Before Push

Run:

```bash
npm ci --ignore-scripts
npm run validate
npm test
npm run build
```

If all commands pass, the package is ready to deploy.

## Command-Line Setup

Replace the remote URL with your actual repository URL:

```bash
git init
git add .
git commit -m "Initial commit: add live deployment package"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Script Setup

macOS / Linux / Git Bash:

```bash
bash scripts/local-init.sh https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
```

Windows PowerShell:

```powershell
.\scripts\local-init.ps1 -RemoteUrl "https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git"
```
