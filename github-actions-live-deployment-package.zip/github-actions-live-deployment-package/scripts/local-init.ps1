param(
  [Parameter(Mandatory=$false)]
  [string]$RemoteUrl
)

$ErrorActionPreference = "Stop"

git init
git add .
git commit -m "Initial commit: add live deployment package"
git branch -M main

if ($RemoteUrl) {
  git remote add origin $RemoteUrl
  git push -u origin main
} else {
  Write-Host "Local repository created."
  Write-Host "To connect GitHub, run:"
  Write-Host "git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git"
  Write-Host "git push -u origin main"
}
