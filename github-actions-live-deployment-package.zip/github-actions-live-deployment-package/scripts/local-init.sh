#!/usr/bin/env bash
set -euo pipefail

REMOTE_URL="${1:-}"

git init
git add .
git commit -m "Initial commit: add live deployment package"
git branch -M main

if [[ -n "$REMOTE_URL" ]]; then
  git remote add origin "$REMOTE_URL"
  git push -u origin main
else
  echo "Local repository created."
  echo "To connect GitHub, run:"
  echo "git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git"
  echo "git push -u origin main"
fi
