import fs from "node:fs";
import path from "node:path";

const requiredFiles = [
  "README.md",
  "package.json",
  "package-lock.json",
  ".github/workflows/ci.yml",
  ".github/workflows/deploy-pages.yml",
  ".github/dependabot.yml",
  "docs/LIVE_DEPLOYMENT_STEPS.md",
  "docs/GITHUB_ACTIONS_SIMPLIFIED.md",
  "docs/GITHUB_PAGES_SETTINGS.md",
  "docs/TROUBLESHOOTING.md",
  "scripts/build-site.js",
  "scripts/validate-package.js",
  "src/index.js",
  "test/smoke.test.js",
  "public/index.html",
  "SECURITY.md"
];

const requiredCiPhrases = [
  "name: CI",
  "on:",
  "permissions:",
  "contents: read",
  "concurrency:",
  "jobs:",
  "runs-on: ubuntu-latest",
  "actions/checkout@v4",
  "actions/setup-node@v4",
  "npm run validate",
  "npm test"
];

const requiredDeployPhrases = [
  "name: Deploy GitHub Pages",
  "pages: write",
  "id-token: write",
  "actions/configure-pages@v5",
  "actions/upload-pages-artifact@v3",
  "actions/deploy-pages@v4",
  "path: ./dist",
  "environment:",
  "github-pages"
];

const forbiddenFiles = [
  ".env",
  ".env.local",
  "secrets.json",
  "credentials.json"
];

function fail(message) {
  console.error(`VALIDATION FAILED: ${message}`);
  process.exit(1);
}

for (const file of requiredFiles) {
  if (!fs.existsSync(file)) {
    fail(`Missing required file: ${file}`);
  }
}

for (const file of forbiddenFiles) {
  if (fs.existsSync(file)) {
    fail(`Sensitive local file should not be committed: ${file}`);
  }
}

const ci = fs.readFileSync(path.join(".github", "workflows", "ci.yml"), "utf8");
const deploy = fs.readFileSync(path.join(".github", "workflows", "deploy-pages.yml"), "utf8");
const index = fs.readFileSync(path.join("public", "index.html"), "utf8");

for (const phrase of requiredCiPhrases) {
  if (!ci.includes(phrase)) {
    fail(`CI workflow is missing required phrase: ${phrase}`);
  }
}

for (const phrase of requiredDeployPhrases) {
  if (!deploy.includes(phrase)) {
    fail(`Deploy workflow is missing required phrase: ${phrase}`);
  }
}

if (!index.includes("__BUILD_TIME__")) {
  fail("public/index.html must include __BUILD_TIME__ placeholder.");
}

console.log("Package validation passed.");
