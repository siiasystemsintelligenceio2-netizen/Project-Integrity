import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const publicDir = path.join(root, "public");
const distDir = path.join(root, "dist");
const sourceIndex = path.join(publicDir, "index.html");
const outputIndex = path.join(distDir, "index.html");
const output404 = path.join(distDir, "404.html");
const noJekyll = path.join(distDir, ".nojekyll");

if (!fs.existsSync(sourceIndex)) {
  console.error("BUILD FAILED: Missing public/index.html");
  process.exit(1);
}

fs.rmSync(distDir, { recursive: true, force: true });
fs.mkdirSync(distDir, { recursive: true });

const buildTime = new Date().toISOString();
const html = fs.readFileSync(sourceIndex, "utf8").replaceAll("__BUILD_TIME__", buildTime);

fs.writeFileSync(outputIndex, html);
fs.writeFileSync(output404, html);
fs.writeFileSync(noJekyll, "");

console.log(`Static site built at ${distDir}`);
console.log(`Build time: ${buildTime}`);
