# Security Policy

## Supported Version

This package is a deployment-ready starter template. Keep your repository updated after using it.

## Secrets

Do not commit:

- API keys
- Tokens
- Passwords
- Client secrets
- `.env` files
- Private credentials

Use GitHub repository secrets for sensitive values.

## GitHub Pages Warning

GitHub Pages publishes a public website. Do not place private business data, credentials, or confidential documents inside `public/` or `dist/`.

## Reporting Security Issues

If this repository becomes a public project, add a contact method here for responsible disclosure.
