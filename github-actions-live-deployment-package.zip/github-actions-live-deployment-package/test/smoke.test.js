import test from "node:test";
import assert from "node:assert/strict";
import { getStatus } from "../src/index.js";

test("live deployment package returns ready status", () => {
  const result = getStatus();

  assert.equal(result.project, "GitHub Actions Live Deployment Package");
  assert.equal(result.status, "ok");
  assert.equal(result.automation, "ready");
  assert.equal(result.deployment, "github-pages");
  assert.equal(result.output, "dist/index.html");
});
